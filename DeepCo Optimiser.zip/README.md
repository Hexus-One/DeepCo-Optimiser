# Compiled tools for DeepCo
For optimal and efficient gameplay\
Compilation of all the hard work put into the spreadsheets made accessible in game
for maximum efficiency

[latest release](https://github.com/4za4s/DeepCo-Optimiser/releases/latest)

# Features
- Block counter for types on blocks mined in current sector

# TODO
- Everything
