// chrome.tabs.onActivated.addListener(({ tabId, windowId }) => {
//     // console.log(tabId);
//     // chrome.tabs.sendMessage(tabId, {});
// });
